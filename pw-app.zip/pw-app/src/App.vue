<script setup>
import PaginaInicial from './pages/paginaInicial.vue';
import Home from './pages/home.vue';

</script>

<template>
  <router-view></router-view>
</template>

